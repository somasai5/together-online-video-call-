/**
 * content_script.js — Together Watch Party
 *
 * Injected into Hotstar pages. Covers:
 *  Stage 2: Extension skeleton + overlay mount
 *  Stage 3: Playback sync (MutationObserver, drift correction, ad detection)
 *  Stage 4: Text chat
 *  Stage 5: Emoji reactions
 *  Stage 6: WebRTC webcam
 *  Stage 7: Fullscreen handling
 */

'use strict';

// ─── Config ───────────────────────────────────────────────────────────────────

/** Public STUN and free global TURN relay servers for reliable cross-network P2P WebRTC */
const ICE_SERVERS = [
  { urls: 'stun:stun.l.google.com:19302' },
  { urls: 'stun:stun1.l.google.com:19302' },
  { urls: 'stun:stun2.l.google.com:19302' },
  { urls: 'stun:stun3.l.google.com:19302' },
  { urls: 'stun:stun4.l.google.com:19302' },
  { urls: 'stun:global.stun.twilio.com:3478' },
  { urls: 'stun:stun.cloudflare.com:3478' },
  { urls: 'stun:openrelay.metered.ca:80' },
  {
    urls: [
      'turn:openrelay.metered.ca:80',
      'turn:openrelay.metered.ca:443',
      'turn:openrelay.metered.ca:443?transport=tcp',
      'turns:openrelay.metered.ca:443?transport=tcp',
      'turns:openrelay.metered.ca:5349?transport=tcp',
    ],
    username: 'openrelayproject',
    credential: 'openrelayproject',
  },
];

const DRIFT_HEARTBEAT_INTERVAL_MS = 1000;   // 1s smooth heartbeat (prevents network / buffer flooding)
const DRIFT_DEADZONE_THRESHOLD    = 0.35;   // 350ms — perfectly synchronized, no seeking or adjustment needed
const DRIFT_HARD_SEEK_THRESHOLD   = 1.5;    // 1.5s — only hard seek if desync is substantial
const HARD_SEEK_COOLDOWN_MS       = 2000;   // 2s cooldown between hard seeks so buffer can fill without interruption

const EMOJIS = ['❤️', '😂', '😮', '👏', '🔥', '😢'];

// ─── State ────────────────────────────────────────────────────────────────────

let roomCode         = null;
let participantId    = null;
let isHost           = false;
let isInRoom         = false;

let videoEl          = null;
let isSyncing        = false;       // guard against feedback loops
let syncEnabled      = true;        // enabled by default
let hostPlaybackRate = 1.0;         // sync movie speed (1x, 1.25x, etc.)

let driftInterval    = null;
let clockSyncInterval = null;
let clockOffsetMs    = 0;          // Host clock offset (NTP measured)
let clockSyncSamples = [];

let lastBroadcastUrl = null;
let pendingMovieUrl  = null;

let isCallActive       = false;
let lastIncomingOffer  = null;

let overlayRoot      = null;        // #together-overlay-root
let panelVisible     = true;

let videoObserver    = null;

// ─── Utility ──────────────────────────────────────────────────────────────────

function cleanupOrphanedScript() {
  try {
    if (videoObserver) {
      videoObserver.disconnect();
      videoObserver = null;
    }
    if (window._togVideoCheckInterval) {
      clearInterval(window._togVideoCheckInterval);
      window._togVideoCheckInterval = null;
    }
    if (driftInterval) {
      clearInterval(driftInterval);
      driftInterval = null;
    }
    if (clockSyncInterval) {
      clearInterval(clockSyncInterval);
      clockSyncInterval = null;
    }
  } catch {}
}

function sendToBackground(payload) {
  try {
    if (!chrome.runtime?.id) {
      cleanupOrphanedScript();
      return;
    }
    chrome.runtime.sendMessage({ ...payload, source: 'content_script' })?.catch(() => {});
  } catch (err) {
    cleanupOrphanedScript();
  }
}

function sendWS(payload) {
  sendToBackground({ type: 'ws-send', payload });
}

function log(...args) {
  console.log('[Together]', ...args);
}

// ─── Overlay injection ────────────────────────────────────────────────────────

function injectOverlay() {
  const existing = document.getElementById('together-overlay-root');
  if (existing) {
    existing.remove();
  }

  // Ensure overlay CSS stylesheet is linked
  if (!document.getElementById('together-overlay-css')) {
    const link = document.createElement('link');
    link.id   = 'together-overlay-css';
    link.rel  = 'stylesheet';
    link.href = chrome.runtime.getURL('overlay.css');
    (document.head || document.documentElement).appendChild(link);
  }

  overlayRoot = document.createElement('div');
  overlayRoot.id = 'together-overlay-root';
  overlayRoot.innerHTML = buildOverlayHTML();

  (document.body || document.documentElement).appendChild(overlayRoot);

  attachOverlayListeners();
  makePipDraggable();
  makePipResizable();
  log('Overlay injected successfully with Watch Party panel');
}

let unreadCount = 0;
let pipMinimized = false;
let toastTimeout = null;

function showChatToast(msg) {
  const toast = document.getElementById('tog-chat-toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.remove('hidden');
  toast.classList.add('visible');
  if (toastTimeout) clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    toast.classList.remove('visible');
    setTimeout(() => toast.classList.add('hidden'), 300);
  }, 3500);
}

function buildOverlayHTML() {
  const emojiButtons = EMOJIS.map(
    (e) => `<button class="tog-emoji-btn" data-emoji="${e}" title="${e}">${e}</button>`
  ).join('');

  return `
    <!-- Top-Center Movie Switch Notification Banner -->
    <div id="tog-movie-banner" class="hidden">
      <span id="tog-movie-text">🎬 Host is watching a different movie</span>
      <div class="tog-movie-banner-btns">
        <button class="tog-btn-switch" id="tog-switch-movie-btn">Switch Movie</button>
        <button class="tog-btn-dismiss" id="tog-dismiss-movie-btn" title="Dismiss">✕</button>
      </div>
    </div>

    <!-- Top-Center Ad Break Notification Banner -->
    <div id="tog-ad-banner" class="hidden">
      <span id="tog-ad-banner-text">🍿 Friend is in an ad break</span>
      <div class="tog-movie-banner-btns">
        <button class="tog-btn-switch" id="tog-ad-action-btn">⏸️ Pause</button>
        <button class="tog-btn-dismiss" id="tog-dismiss-ad-btn" title="Dismiss">✕</button>
      </div>
    </div>

    <!-- Top-Right Incoming Call Banner -->
    <div id="tog-call-banner" class="hidden">
      <span>📞 Friend is calling you...</span>
      <div class="tog-call-banner-btns">
        <button class="tog-action-btn tog-btn-answer" id="tog-answer-call-btn">Answer</button>
        <button class="tog-action-btn tog-btn-decline" id="tog-decline-call-btn">Decline</button>
      </div>
    </div>

    <!-- Autoplay Sync Enable Banner -->
    <div id="tog-sync-banner" class="hidden">
      ▶ Join &amp; Enable Sync
    </div>

    <!-- Desync Resume Prompt -->
    <div id="tog-desync-prompt" class="hidden">
      ▶ Playback out of sync — click to resume
    </div>

    <!-- ── Floating Picture-in-Picture (PiP) Window (Extendable & Draggable) ── -->
    <div id="tog-pip-window">
      <!-- PiP Window Draggable Header -->
      <div id="tog-pip-header">
        <div class="tog-pip-drag-handle">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="currentColor"><circle cx="4" cy="6" r="2"/><circle cx="12" cy="6" r="2"/><circle cx="20" cy="6" r="2"/><circle cx="4" cy="18" r="2"/><circle cx="12" cy="18" r="2"/><circle cx="20" cy="18" r="2"/></svg>
          <span class="tog-pip-logo-text">Together</span>
          <span class="tog-pip-room-pill" id="tog-pip-room-code">${escapeHTML(roomCode || '———')}</span>
        </div>
        <div class="tog-pip-window-controls">
          <button class="tog-pip-icon-btn" id="tog-pip-size-btn" title="Resize Screen: Compact / Medium / Large / Theater">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 3 21 3 21 9"/><polyline points="9 21 3 21 3 15"/><line x1="21" y1="3" x2="14" y2="10"/><line x1="3" y1="21" x2="10" y2="14"/></svg>
          </button>
          <button class="tog-pip-icon-btn" id="tog-pip-chat-toggle" title="Open / Close Chat">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            <span id="tog-chat-unread-badge" class="hidden">0</span>
          </button>
          <button class="tog-pip-icon-btn" id="tog-pip-minimize-btn" title="Collapse Video">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </button>
          <button class="tog-pip-icon-btn" id="tog-pip-close-btn" title="Dock to Corner Button">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
          </button>
        </div>
      </div>

      <!-- Now Watching Compact Movie Bar -->
      <div id="tog-pip-movie-bar">
        <div id="tog-pip-movie-info">
          <span id="tog-pip-movie-icon">🎬</span>
          <div id="tog-pip-movie-title" class="tog-pip-movie-title">
            ${isHost ? escapeHTML(getMovieTitle(window.location.href)) : 'Waiting for host…'}
          </div>
        </div>
        <button id="tog-pip-switch-btn" class="tog-pip-switch-btn hidden">
          Switch
        </button>
      </div>

      <!-- Dual Webcam Video Section (Hosted in Extension Iframe to bypass Hotstar CSP) -->
      <div id="tog-webcam-section">
        <iframe id="tog-webcam-frame" src="${chrome.runtime.getURL('webrtc_bridge.html')}" allow="camera; microphone; autoplay"></iframe>
      </div>

      <!-- Quick Control Toolbar -->
      <div id="tog-pip-toolbar">
        <div class="tog-pip-media-btns">
          <button class="tog-ctrl-btn" id="tog-mute-btn" title="Mute / Unmute Microphone">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/>
              <path d="M19 10v2a7 7 0 0 1-14 0v-2"/>
              <line x1="12" y1="19" x2="12" y2="23"/>
              <line x1="8" y1="23" x2="16" y2="23"/>
            </svg>
          </button>
          <button class="tog-ctrl-btn" id="tog-cam-btn" title="Toggle Camera On / Off">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M23 7l-7 5 7 5V7z"/><rect x="1" y="5" width="15" height="14" rx="2"/>
            </svg>
          </button>
          <button class="tog-ctrl-btn tog-btn-call" id="tog-call-btn" title="Start Video Call">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.49 12 19.79 19.79 0 0 1 1.45 3.4 2 2 0 0 1 3.42 1h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L7.91 8.4a16 16 0 0 0 5.69 5.69l.84-.84a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"/>
            </svg>
          </button>
          <button class="tog-ctrl-btn tog-btn-ad" id="tog-ad-btn" title="Notify friend: I am in an ad break">
            🍿
          </button>
        </div>
        <div class="tog-pip-emoji-row" id="tog-emoji-bar">${emojiButtons}</div>
      </div>

      <!-- Pop-up Expandable Chat Box -->
      <div id="tog-chat-popover" class="hidden">
        <div id="tog-chat-messages" role="log" aria-live="polite"></div>
        <div id="tog-chat-input-row">
          <textarea id="tog-chat-input" placeholder="Message…" rows="1" maxlength="500"></textarea>
          <button id="tog-send-btn" title="Send message">
            <svg viewBox="0 0 24 24"><line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/></svg>
          </button>
        </div>
      </div>

      <!-- Transient Chat Toast (Appears briefly on incoming messages when popover is closed) -->
      <div id="tog-chat-toast" class="hidden"></div>

      <!-- Drag-to-Resize Corner Grip Handle -->
      <div id="tog-pip-resizer" title="Drag to resize video window">
        <svg width="10" height="10" viewBox="0 0 10 10" fill="currentColor">
          <circle cx="8" cy="2" r="1.2"/>
          <circle cx="8" cy="5" r="1.2"/>
          <circle cx="5" cy="5" r="1.2"/>
          <circle cx="8" cy="8" r="1.2"/>
          <circle cx="5" cy="8" r="1.2"/>
          <circle cx="2" cy="8" r="1.2"/>
        </svg>
      </div>
    </div>

    <!-- ── Floating Action Button (Shows when PiP is docked) ── -->
    <button id="tog-toggle-btn" class="hidden" title="Open Watch Party">
      <span id="tog-unread-badge" class="hidden">0</span>
      <svg viewBox="0 0 24 24">
        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
      </svg>
    </button>
  `;
}

function makePipDraggable() {
  const pip = document.getElementById('tog-pip-window');
  const header = document.getElementById('tog-pip-header');
  if (!pip || !header) return;

  let isDragging = false;
  let startX = 0, startY = 0;
  let initialLeft = 0, initialTop = 0;

  header.addEventListener('mousedown', (e) => {
    if (e.target.closest('.tog-pip-icon-btn') || e.target.closest('button')) return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = pip.getBoundingClientRect();
    initialLeft = rect.left;
    initialTop = rect.top;

    pip.style.right = 'auto';
    pip.style.bottom = 'auto';
    pip.style.left = `${initialLeft}px`;
    pip.style.top = `${initialTop}px`;
    pip.style.transition = 'none';

    const onMouseMove = (ev) => {
      if (!isDragging) return;
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;

      let newLeft = initialLeft + dx;
      let newTop = initialTop + dy;

      const maxLeft = window.innerWidth - pip.offsetWidth - 12;
      const maxTop = window.innerHeight - pip.offsetHeight - 12;
      newLeft = Math.max(12, Math.min(newLeft, maxLeft));
      newTop = Math.max(12, Math.min(newTop, maxTop));

      pip.style.left = `${newLeft}px`;
      pip.style.top = `${newTop}px`;
    };

    const onMouseUp = () => {
      isDragging = false;
      pip.style.transition = '';
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  });
}

function makePipResizable() {
  const pip = document.getElementById('tog-pip-window');
  const resizer = document.getElementById('tog-pip-resizer');
  if (!pip || !resizer) return;

  let isResizing = false;
  let startX = 0, startY = 0;
  let startWidth = 0, startHeight = 0;

  resizer.addEventListener('mousedown', (e) => {
    e.stopPropagation();
    e.preventDefault();
    isResizing = true;
    startX = e.clientX;
    startY = e.clientY;
    startWidth = pip.offsetWidth;
    const webcamSection = document.getElementById('tog-webcam-section');
    startHeight = webcamSection ? webcamSection.offsetHeight : 135;
    pip.style.transition = 'none';

    const onMouseMove = (ev) => {
      if (!isResizing) return;
      const dx = ev.clientX - startX;
      const dy = ev.clientY - startY;
      // Width driven by horizontal drag
      let newWidth = Math.max(260, Math.min(startWidth + dx, window.innerWidth - 30));
      pip.style.width = `${newWidth}px`;
      // Video section height driven by vertical drag; fallback to proportional width change
      const webcamSection = document.getElementById('tog-webcam-section');
      if (webcamSection) {
        let newHeight = Math.max(110, Math.min(startHeight + dy, 500));
        webcamSection.style.height = `${newHeight}px`;
      }
    };

    const onMouseUp = () => {
      isResizing = false;
      pip.style.transition = '';
      document.removeEventListener('mousemove', onMouseMove);
      document.removeEventListener('mouseup', onMouseUp);
    };

    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  });
}

function attachOverlayListeners() {
  const pipWindow = document.getElementById('tog-pip-window');
  const toggleBtn = document.getElementById('tog-toggle-btn');
  const closeBtn = document.getElementById('tog-pip-close-btn');
  const minimizeBtn = document.getElementById('tog-pip-minimize-btn');
  const sizeBtn = document.getElementById('tog-pip-size-btn');
  const chatToggleBtn = document.getElementById('tog-pip-chat-toggle');
  const chatPopover = document.getElementById('tog-chat-popover');
  const chatBadge = document.getElementById('tog-chat-unread-badge');
  const fabBadge = document.getElementById('tog-unread-badge');

  // Size preset cycler
  const SIZES = [
    { name: 'Compact',  width: '290px' },
    { name: 'Medium',   width: '440px' },
    { name: 'Large',    width: '620px' },
    { name: 'Theater',  width: '820px' },
  ];
  let currentSizeIdx = 0;

  sizeBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    currentSizeIdx = (currentSizeIdx + 1) % SIZES.length;
    const target = SIZES[currentSizeIdx];
    if (pipWindow) {
      pipWindow.style.width = target.width;
      // Clamping within viewport if right edge exceeds screen
      const rect = pipWindow.getBoundingClientRect();
      if (rect.right > window.innerWidth - 10) {
        pipWindow.style.left = `${Math.max(10, window.innerWidth - pipWindow.offsetWidth - 15)}px`;
        pipWindow.style.right = 'auto';
      }
    }
    showChatToast(`📐 Screen Size: ${target.name} (${target.width})`);
  });

  // Spotlight click on remote (friend) video
  document.getElementById('tog-remote-tile')?.addEventListener('click', () => {
    const sec = document.getElementById('tog-webcam-section');
    if (!sec) return;
    if (sec.classList.contains('spotlight-remote')) {
      sec.classList.remove('spotlight-remote');
      showChatToast('👥 Dual View');
    } else {
      sec.classList.remove('spotlight-local');
      sec.classList.add('spotlight-remote');
      showChatToast('🔍 Spotlight: Friend (Full Screen)');
    }
  });

  // Spotlight click on local (you) video
  document.getElementById('tog-local-tile')?.addEventListener('click', () => {
    const sec = document.getElementById('tog-webcam-section');
    if (!sec) return;
    if (sec.classList.contains('spotlight-local')) {
      sec.classList.remove('spotlight-local');
      showChatToast('👥 Dual View');
    } else {
      sec.classList.remove('spotlight-remote');
      sec.classList.add('spotlight-local');
      showChatToast('🔍 Spotlight: You');
    }
  });

  function openChatPopover() {
    chatPopover?.classList.remove('hidden');
    chatToggleBtn?.classList.add('active');
    unreadCount = 0;
    if (chatBadge) {
      chatBadge.textContent = '0';
      chatBadge.classList.add('hidden');
    }
    if (fabBadge) {
      fabBadge.textContent = '0';
      fabBadge.classList.add('hidden');
    }
    setTimeout(() => {
      document.getElementById('tog-chat-input')?.focus();
    }, 50);
  }

  function closeChatPopover() {
    chatPopover?.classList.add('hidden');
    chatToggleBtn?.classList.remove('active');
  }

  // Toggle Chat Popover
  chatToggleBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    if (chatPopover?.classList.contains('hidden')) {
      openChatPopover();
    } else {
      closeChatPopover();
    }
  });

  // Collapse / Minimize Webcam Video section
  minimizeBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    const sec = document.getElementById('tog-webcam-section');
    if (sec) {
      pipMinimized = !pipMinimized;
      sec.style.display = pipMinimized ? 'none' : 'flex';
      minimizeBtn.title = pipMinimized ? 'Expand Video' : 'Collapse Video';
      minimizeBtn.innerHTML = pipMinimized
        ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>`
        : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/></svg>`;
    }
  });

  // Dock PiP window into floating bubble
  closeBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    pipWindow?.classList.add('hidden');
    toggleBtn?.classList.remove('hidden');
  });

  // Restore PiP window from bubble
  toggleBtn?.addEventListener('click', (e) => {
    e.stopPropagation();
    pipWindow?.classList.remove('hidden');
    toggleBtn?.classList.add('hidden');
    unreadCount = 0;
    if (fabBadge) {
      fabBadge.textContent = '0';
      fabBadge.classList.add('hidden');
    }
  });

  // Fast Movie switch handler
  function fastNavigate(targetUrl) {
    if (!targetUrl) return;

    let urlToLoad = targetUrl;
    try {
      const u = new URL(targetUrl, window.location.origin);
      if ((u.pathname.includes('/movies/') || u.pathname.includes('/shows/')) && !u.pathname.endsWith('/watch') && !u.pathname.includes('/watch/')) {
        u.pathname = u.pathname.replace(/\/+$/, '') + '/watch';
        urlToLoad = u.toString();
      }
    } catch {}

    const pipSwitchBtn = document.getElementById('tog-pip-switch-btn');
    const bannerSwitchBtn = document.getElementById('tog-switch-movie-btn');
    if (pipSwitchBtn) {
      pipSwitchBtn.innerHTML = '⏳ Loading…';
      pipSwitchBtn.disabled = true;
    }
    if (bannerSwitchBtn) {
      bannerSwitchBtn.innerHTML = '⏳ Loading…';
      bannerSwitchBtn.disabled = true;
    }

    log('Fast navigating to movie:', urlToLoad);

    const cleanPath = new URL(urlToLoad, window.location.origin).pathname;
    const existingLink = Array.from(document.querySelectorAll('a')).find((a) => {
      try {
        const href = a.getAttribute('href');
        return href && (href.includes(cleanPath) || cleanPath.includes(href));
      } catch {
        return false;
      }
    });

    if (existingLink) {
      existingLink.click();
      setTimeout(() => {
        if (window.location.href !== urlToLoad) {
          window.location.assign(urlToLoad);
        }
      }, 120);
      return;
    }

    window.location.assign(urlToLoad);
  }

  const onSwitchMovie = () => {
    if (pendingMovieUrl) {
      fastNavigate(pendingMovieUrl);
    }
  };
  document.getElementById('tog-switch-movie-btn')?.addEventListener('click', onSwitchMovie);
  document.getElementById('tog-pip-switch-btn')?.addEventListener('click', onSwitchMovie);
  document.getElementById('tog-dismiss-movie-btn')?.addEventListener('click', () => {
    document.getElementById('tog-movie-banner')?.classList.add('hidden');
  });

  // Sync banner (guest interaction to satisfy autoplay policy)
  document.getElementById('tog-sync-banner')?.addEventListener('click', () => {
    syncEnabled = true;
    document.getElementById('tog-sync-banner')?.classList.add('hidden');
    if (!isHost) {
      sendWS({ type: 'state-request' });
    }
    log('Sync enabled by user interaction');
  });

  // Desync prompt
  document.getElementById('tog-desync-prompt')?.addEventListener('click', () => {
    document.getElementById('tog-desync-prompt')?.classList.add('hidden');
    if (videoEl) {
      videoEl.play().catch(() => {});
    }
  });

  // Incoming call banner buttons
  document.getElementById('tog-answer-call-btn')?.addEventListener('click', () => {
    document.getElementById('tog-call-banner')?.classList.add('hidden');
    document.getElementById('tog-call-btn')?.classList.remove('tog-btn-ringing');
    sendToBridge({ type: 'answer-call', offer: lastIncomingOffer });
    lastIncomingOffer = null;
  });
  document.getElementById('tog-decline-call-btn')?.addEventListener('click', () => {
    document.getElementById('tog-call-banner')?.classList.add('hidden');
    document.getElementById('tog-call-btn')?.classList.remove('tog-btn-ringing');
    lastIncomingOffer = null;
    sendToBridge({ type: 'end-call', notify: true });
    appendChatMessage('Declined video call.', 'system');
  });

  // Emoji buttons
  document.getElementById('tog-emoji-bar')?.addEventListener('click', (e) => {
    const btn = e.target.closest('.tog-emoji-btn');
    if (!btn) return;
    const emoji = btn.dataset.emoji;
    sendWS({ type: 'emoji', emoji });
    spawnEmojiFloat(emoji);
  });

  // Chat send
  const chatInput = document.getElementById('tog-chat-input');
  document.getElementById('tog-send-btn')?.addEventListener('click', sendChatMessage);
  chatInput?.addEventListener('keydown', (e) => {
    e.stopPropagation();
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendChatMessage();
    }
  });
  chatInput?.addEventListener('input', () => {
    chatInput.style.height = 'auto';
    chatInput.style.height = Math.min(chatInput.scrollHeight, 80) + 'px';
  });
  chatInput?.addEventListener('keyup', (e) => e.stopPropagation());
  chatInput?.addEventListener('keypress', (e) => e.stopPropagation());

  // Stop hotkey propagation on the whole overlay to prevent accidental movie pause/seek
  overlayRoot?.addEventListener('keydown', (e) => e.stopPropagation());

  // WebRTC controls
  document.getElementById('tog-call-btn')?.addEventListener('click', handleCallToggle);
  document.getElementById('tog-mute-btn')?.addEventListener('click', handleMuteToggle);
  document.getElementById('tog-cam-btn')?.addEventListener('click', handleCamToggle);

  // Ad Break Alert control
  document.getElementById('tog-ad-btn')?.addEventListener('click', toggleAdNotification);
  document.getElementById('tog-dismiss-ad-btn')?.addEventListener('click', () => {
    document.getElementById('tog-ad-banner')?.classList.add('hidden');
  });

  // Fullscreen change — reparent overlay
  document.addEventListener('fullscreenchange', onFullscreenChange);
  document.addEventListener('webkitfullscreenchange', onFullscreenChange);
}

// ─── Movie / URL sync helpers ────────────────────────────────────────────────

let lastKnownHostUrl   = null;
let lastKnownHostTitle = null;
let lastTrackedUrl     = window.location.href;
let movieSyncInterval  = null;

function getMovieTitle(targetUrl = window.location.href) {
  try {
    const parsed = new URL(targetUrl, window.location.origin);
    const path = parsed.pathname.replace(/\/+$/, '');
    const segments = path.split('/').filter(Boolean);

    // Scan for category keywords in path: movies, shows, clips, tv, sports, series
    for (let i = 0; i < segments.length; i++) {
      const seg = segments[i].toLowerCase();
      if (['movies', 'shows', 'clips', 'tv', 'sports', 'series', 'watch'].includes(seg)) {
        for (let j = i + 1; j < segments.length; j++) {
          const nextSeg = segments[j];
          if (nextSeg && !/^\d+$/.test(nextSeg) && nextSeg !== 'watch') {
            return nextSeg
              .replace(/[-_]+/g, ' ')
              .split(' ')
              .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
              .join(' ');
          }
        }
      }
    }
  } catch {}

  // If on active page, check DOM headings
  if (targetUrl === window.location.href) {
    const titleSelectors = [
      '[data-testid="player-title"]',
      '[data-testid*="title"]',
      'h1',
      'h2',
      '.player-title',
      '.tray-title',
      '.movie-title',
      '.watch-title',
    ];
    for (const sel of titleSelectors) {
      const el = document.querySelector(sel);
      if (el && el.textContent.trim()) {
        const text = el.textContent.trim();
        if (text.length > 1 && text.length < 80 && !/Disney\+|Hotstar|Upgrade|Home|Search/i.test(text)) {
          return text;
        }
      }
    }

    const docTitle = document.title
      .replace(/\s*[-|•–]\s*(Disney\+?\s*)?Hotstar.*$/i, '')
      .replace(/^Watch\s+/i, '')
      .trim();

    if (docTitle && docTitle.length > 1 && !/Disney\+|Hotstar|Home/i.test(docTitle)) {
      return docTitle;
    }
  }

  if (targetUrl.includes('/in/home') || targetUrl.endsWith('/home') || targetUrl === 'https://www.hotstar.com/' || targetUrl === 'https://hotstar.com/') {
    return 'Hotstar Home';
  }

  return 'Hotstar Video';
}

function normalizeUrl(u) {
  if (!u) return '';
  try {
    const parsed = new URL(u, window.location.origin);
    let path = parsed.pathname.replace(/\/+$/, '').toLowerCase();
    path = path.replace(/\/watch$/, '');
    return path;
  } catch {
    return String(u).trim().toLowerCase();
  }
}

function escapeHTML(str) {
  return String(str).replace(/[&<>'"]/g, (tag) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    "'": '&#39;',
    '"': '&quot;',
  }[tag] || tag));
}

let lastRenderedMovieStateKey = '';

function updateDrawerMovieCard(url, title, isHostRole) {
  const titleEl = document.getElementById('tog-pip-movie-title') || document.getElementById('tog-drawer-movie-title');
  const switchBtn = document.getElementById('tog-pip-switch-btn') || document.getElementById('tog-drawer-switch-btn');
  const banner = document.getElementById('tog-movie-banner');
  const bannerText = document.getElementById('tog-movie-text');

  if (!titleEl) return;

  const currentNorm = normalizeUrl(window.location.href);
  const targetNorm  = lastKnownHostUrl ? normalizeUrl(lastKnownHostUrl) : '';
  const hostTitle   = lastKnownHostTitle || (lastKnownHostUrl ? getMovieTitle(lastKnownHostUrl) : "Host's Movie");

  const stateKey = `${isHostRole}|${url}|${title}|${lastKnownHostUrl}|${currentNorm}|${targetNorm}|${hostTitle}`;
  if (stateKey === lastRenderedMovieStateKey) return;
  lastRenderedMovieStateKey = stateKey;

  if (isHostRole) {
    titleEl.innerHTML = `<strong>Watching:</strong> ${escapeHTML(title || 'Hotstar')}`;
    if (switchBtn) switchBtn.classList.add('hidden');
    if (banner) banner.classList.add('hidden');
    return;
  }

  // Guest role
  if (!lastKnownHostUrl) {
    titleEl.innerHTML = `<em>Waiting for host…</em>`;
    if (switchBtn) switchBtn.classList.add('hidden');
    if (banner) banner.classList.add('hidden');
    return;
  }

  if (currentNorm !== targetNorm) {
    pendingMovieUrl = lastKnownHostUrl;
    titleEl.innerHTML = `<span style="color:#f59e0b">Host is on:</span> <strong>${escapeHTML(hostTitle)}</strong>`;
    if (switchBtn) {
      switchBtn.textContent = `Switch`;
      switchBtn.disabled = false;
      switchBtn.classList.remove('hidden');
    }
    if (bannerText) {
      bannerText.innerHTML = `🎬 Host is watching: <strong>${escapeHTML(hostTitle)}</strong>`;
    }
    if (banner) {
      const bBtn = document.getElementById('tog-switch-movie-btn');
      if (bBtn) bBtn.disabled = false;
      banner.classList.remove('hidden');
    }
  } else {
    pendingMovieUrl = null;
    titleEl.innerHTML = `<span style="color:#10b981">✓ In Sync:</span> <strong>${escapeHTML(hostTitle)}</strong>`;
    if (switchBtn) switchBtn.classList.add('hidden');
    if (banner) banner.classList.add('hidden');
  }
}

function broadcastMovieUrlIfNeeded(force = false) {
  if (!isHost || !isInRoom) return;
  const currentUrl = window.location.href;
  const title = getMovieTitle(currentUrl);
  if (force || currentUrl !== lastBroadcastUrl) {
    lastBroadcastUrl = currentUrl;
    sendWS({
      type: 'movie-change',
      url: currentUrl,
      title: title,
      sentAt: Date.now(),
    });
    log('Host broadcasted movie URL:', currentUrl, title);
  }
  updateDrawerMovieCard(currentUrl, title, true);
}

function handleIncomingMovieUrl(targetUrl, targetTitle) {
  if (isHost || !targetUrl) return;
  const isNewUrl = !lastKnownHostUrl || normalizeUrl(lastKnownHostUrl) !== normalizeUrl(targetUrl);
  lastKnownHostUrl = targetUrl;
  if (targetTitle) lastKnownHostTitle = targetTitle;

  if (isNewUrl && targetTitle) {
    appendChatMessage(`🎬 Host switched to: ${targetTitle}`, 'system');
  }

  checkMovieUrlMatch();
}

function checkMovieUrlMatch() {
  if (isHost || !isInRoom) return;
  if (!overlayRoot) {
    injectOverlay();
  }
  updateDrawerMovieCard(lastKnownHostUrl, lastKnownHostTitle, false);
}

function startMovieSyncMonitor() {
  if (movieSyncInterval) clearInterval(movieSyncInterval);
  movieSyncInterval = setInterval(() => {
    if (!isInRoom || !chrome.runtime?.id) return;

    const currentUrl = window.location.href;
    if (currentUrl !== lastTrackedUrl) {
      lastTrackedUrl = currentUrl;
      log('SPA Navigation detected:', currentUrl);
      if (isHost) {
        broadcastMovieUrlIfNeeded(true);
      } else {
        checkMovieUrlMatch();
      }
    }

    if (isHost) {
      broadcastMovieUrlIfNeeded(false);
    } else {
      checkMovieUrlMatch();
    }
  }, 500);
}

function hookSpaNavigation() {
  if (window._togSpaHooked) return;
  window._togSpaHooked = true;

  window.addEventListener('popstate', onUrlOrNavChange);
  window.addEventListener('hashchange', onUrlOrNavChange);
}

function onUrlOrNavChange() {
  if (!isInRoom) return;
  if (isHost) {
    broadcastMovieUrlIfNeeded(true);
  } else {
    checkMovieUrlMatch();
  }
}

function getAllVideosInTree(node = document) {
  const list = [];
  try {
    if (node.querySelectorAll) {
      const vids = Array.from(node.querySelectorAll('video'));
      list.push(...vids);
    }
    const allEls = node.querySelectorAll ? Array.from(node.querySelectorAll('*')) : [];
    for (const el of allEls) {
      if (el.shadowRoot) {
        list.push(...getAllVideosInTree(el.shadowRoot));
      }
    }
    const iframes = node.querySelectorAll ? Array.from(node.querySelectorAll('iframe')) : [];
    for (const ifr of iframes) {
      try {
        if (ifr.contentDocument) {
          list.push(...getAllVideosInTree(ifr.contentDocument));
        }
      } catch {}
    }
  } catch {}
  return list;
}

function findMainVideo() {
  const allVideos = getAllVideosInTree(document);
  const videos = allVideos.filter((v) => {
    return (
      v.id !== 'tog-local-video' &&
      v.id !== 'tog-remote-video' &&
      !v.closest('#together-overlay-root')
    );
  });

  if (videos.length === 0) return null;
  if (videos.length === 1) return videos[0];

  let best = videos[0];
  let maxArea = -1;
  for (const v of videos) {
    const rect = v.getBoundingClientRect();
    const area = rect.width * rect.height;
    const score = area + (!v.paused && v.currentTime > 0 ? 1000000 : 0);
    if (score > maxArea) {
      maxArea = score;
      best = v;
    }
  }
  return best;
}

let isAttachingVideo = false;

function startVideoObserver() {
  if (videoObserver) {
    videoObserver.disconnect();
    videoObserver = null;
  }
  hookSpaNavigation();

  function tryAttach() {
    if (isAttachingVideo || !chrome.runtime?.id) return;
    if (videoEl && !videoEl.isConnected) {
      videoEl = null;
    }
    isAttachingVideo = true;

    try {
      const v = findMainVideo();
      if (v && v !== videoEl) {
        videoEl = v;
        attachVideoListeners(v);
        log('Main video element attached:', v);
        if (!isHost) {
          sendWS({ type: 'state-request' });
        }
      }
    } finally {
      isAttachingVideo = false;
    }
  }

  tryAttach();

  let attachScheduled = false;
  videoObserver = new MutationObserver(() => {
    if (!attachScheduled) {
      attachScheduled = true;
      requestAnimationFrame(() => {
        attachScheduled = false;
        tryAttach();
      });
    }
  });

  if (document.body) {
    videoObserver.observe(document.body, { childList: true, subtree: true });
  }

  if (window._togVideoCheckInterval) {
    clearInterval(window._togVideoCheckInterval);
  }
  window._togVideoCheckInterval = setInterval(tryAttach, 800);
}

function attachVideoListeners(v) {
  if (v._togListenersAttached) return;
  v._togListenersAttached = true;

  v.addEventListener('play',       onVideoPlay);
  v.addEventListener('pause',      onVideoPause);
  v.addEventListener('seeking',    onVideoSeeking);
  v.addEventListener('seeked',     onVideoSeeked);
  v.addEventListener('ratechange', onVideoRateChange);
  log('Hooked play/pause/seeking/seeked/ratechange listeners to main video');
}

// ─── Playback sync — bi-directional (Host & Guest) ───────────────────────────

let ignoreLocalEventsUntil = 0;
let lastSentAction = null;
let lastSentActionTime = 0;

function onVideoPlay() {
  if (!isInRoom || isSyncing || Date.now() < ignoreLocalEventsUntil) return;

  const now = Date.now();
  if (lastSentAction === 'play' && now - lastSentActionTime < 250) return;
  lastSentAction = 'play';
  lastSentActionTime = now;

  log('Broadcasting PLAY event...');
  sendWS({
    type: 'sync',
    action: 'play',
    currentTime: videoEl ? videoEl.currentTime : 0,
    rate: videoEl ? videoEl.playbackRate : 1.0,
    url: window.location.href,
    title: getMovieTitle(),
    sentAt: Date.now(),
  });
}

function onVideoPause() {
  if (!isInRoom || isSyncing || Date.now() < ignoreLocalEventsUntil) return;

  const now = Date.now();
  if (lastSentAction === 'pause' && now - lastSentActionTime < 250) return;
  lastSentAction = 'pause';
  lastSentActionTime = now;

  log('Broadcasting PAUSE event...');
  sendWS({
    type: 'sync',
    action: 'pause',
    currentTime: videoEl ? videoEl.currentTime : 0,
    rate: videoEl ? videoEl.playbackRate : 1.0,
    url: window.location.href,
    title: getMovieTitle(),
    sentAt: Date.now(),
  });
}

function onVideoSeeking() {
  if (!isInRoom || isSyncing || Date.now() < ignoreLocalEventsUntil) return;
  if (videoEl && videoEl.currentTime < 0.5 && videoEl.readyState < 2) return;

  const now = Date.now();
  if (lastSentAction === 'seek' && now - lastSentActionTime < 150) return;
  lastSentAction = 'seek';
  lastSentActionTime = now;

  sendWS({
    type: 'sync',
    action: 'seek',
    currentTime: videoEl ? videoEl.currentTime : 0,
    rate: videoEl ? videoEl.playbackRate : 1.0,
    url: window.location.href,
    title: getMovieTitle(),
    sentAt: Date.now(),
  });
}

function onVideoSeeked() {
  if (!isInRoom || isSyncing || Date.now() < ignoreLocalEventsUntil) return;
  if (videoEl && videoEl.currentTime < 0.5 && videoEl.readyState < 2) return;

  const now = Date.now();
  if (lastSentAction === 'seek' && now - lastSentActionTime < 150) return;
  lastSentAction = 'seek';
  lastSentActionTime = now;

  sendWS({
    type: 'sync',
    action: 'seek',
    currentTime: videoEl ? videoEl.currentTime : 0,
    rate: videoEl ? videoEl.playbackRate : 1.0,
    url: window.location.href,
    title: getMovieTitle(),
    sentAt: Date.now(),
  });
}

function onVideoRateChange() {
  if (!isInRoom || isSyncing || Date.now() < ignoreLocalEventsUntil) return;

  sendWS({
    type: 'sync',
    action: 'ratechange',
    rate: videoEl ? videoEl.playbackRate : 1.0,
    currentTime: videoEl ? videoEl.currentTime : 0,
    url: window.location.href,
    title: getMovieTitle(),
    sentAt: Date.now(),
  });
}

// ─── Clock Skew & Network Latency Calibration (NTP Algorithm) ─────────────────

function startClockSync() {
  if (isHost || !isInRoom) return;
  clearInterval(clockSyncInterval);
  clockSyncInterval = setInterval(() => {
    if (!isInRoom || isHost || !chrome.runtime?.id) return;
    sendWS({
      type: 'clock-ping',
      t0: Date.now(),
    });
  }, 2000);

  sendWS({ type: 'clock-ping', t0: Date.now() });
  setTimeout(() => sendWS({ type: 'clock-ping', t0: Date.now() }), 300);
  setTimeout(() => sendWS({ type: 'clock-ping', t0: Date.now() }), 600);
}

function handleClockPing(message) {
  if (!isHost) return;
  sendWS({
    type: 'clock-pong',
    t0: message.t0,
    t1: Date.now(),
  });
}

function handleClockPong(message) {
  if (isHost) return;
  const t3 = Date.now();
  const t0 = message.t0;
  const t1 = message.t1;
  if (!t0 || !t1) return;

  const rtt = Math.max(t3 - t0, 0);
  const offset = t1 - (t0 + rtt / 2);

  clockSyncSamples.push(offset);
  if (clockSyncSamples.length > 7) clockSyncSamples.shift();

  const sorted = [...clockSyncSamples].sort((a, b) => a - b);
  clockOffsetMs = sorted[Math.floor(sorted.length / 2)];
}

function getCorrectedHostTime(hostTime, sentAt, hostPaused, hostRate) {
  const baseRate = (typeof hostRate === 'number' && hostRate > 0) ? hostRate : (hostPlaybackRate || 1.0);
  if (!sentAt) return hostTime;

  const now = Date.now();
  const offset = isHost ? 0 : clockOffsetMs;
  const hostNowEstimate = now + offset;
  const elapsedSeconds = Math.max((hostNowEstimate - sentAt) / 1000, 0);

  return hostPaused ? hostTime : (hostTime + (elapsedSeconds * baseRate));
}

let lastHardSeekTime = 0;

function forcePlayVideo(targetTime = null) {
  if (!videoEl || !videoEl.isConnected) {
    const v = findMainVideo();
    if (v) {
      videoEl = v;
      attachVideoListeners(v);
    }
  }

  if (!videoEl) return;

  isSyncing = true;
  ignoreLocalEventsUntil = Date.now() + 400;

  if (typeof targetTime === 'number' && targetTime >= 0 && Math.abs(videoEl.currentTime - targetTime) > 0.35) {
    try {
      videoEl.currentTime = targetTime;
    } catch {}
  }

  const playPromise = videoEl.play();
  if (playPromise !== undefined) {
    playPromise.catch((err) => {
      log('Direct play prevented, clicking UI play button:', err.message);
      const playBtnSelectors = [
        '[data-testid*="play-pause"]',
        '[data-testid*="play"]',
        'button[aria-label*="Play" i]',
        'button[aria-label*="play" i]',
        '.play-btn',
        '.player-play-btn',
        '.play-icon',
        '.shaka-play-button',
      ];
      let clicked = false;
      for (const sel of playBtnSelectors) {
        const btn = document.querySelector(sel);
        if (btn && btn.offsetParent !== null && !btn.closest('#together-overlay-root')) {
          btn.click();
          clicked = true;
          break;
        }
      }

      if (!clicked) {
        document.getElementById('tog-desync-prompt')?.classList.remove('hidden');
      }
    });
  }

  setTimeout(() => { isSyncing = false; }, 200);
}

function forcePauseVideo() {
  if (!videoEl || !videoEl.isConnected) {
    const v = findMainVideo();
    if (v) {
      videoEl = v;
      attachVideoListeners(v);
    }
  }
  if (!videoEl) return;

  isSyncing = true;
  ignoreLocalEventsUntil = Date.now() + 400;

  try {
    videoEl.pause();
    if (!videoEl.paused) {
      const pauseBtnSelectors = [
        '[data-testid*="play-pause"]',
        '[data-testid*="pause"]',
        'button[aria-label*="Pause" i]',
        'button[aria-label*="pause" i]',
        '.pause-btn',
        '.player-pause-btn',
        '.pause-icon',
        '.shaka-pause-button',
      ];
      for (const sel of pauseBtnSelectors) {
        const btn = document.querySelector(sel);
        if (btn && btn.offsetParent !== null && !btn.closest('#together-overlay-root')) {
          btn.click();
          break;
        }
      }
    }
  } catch (err) {
    log('forcePauseVideo error:', err);
  } finally {
    setTimeout(() => { isSyncing = false; }, 200);
  }
}

// ─── Playback sync — applying incoming sync ───────────────────────────────────

function applySync(action, currentTime, sentAt, rate) {
  if (!videoEl || !videoEl.isConnected) {
    const v = findMainVideo();
    if (v) {
      videoEl = v;
      attachVideoListeners(v);
    }
  }
  if (!videoEl) return;

  if (typeof rate === 'number' && rate > 0) {
    hostPlaybackRate = rate;
  }
  const baseRate = hostPlaybackRate || 1.0;
  const targetTime = getCorrectedHostTime(currentTime, sentAt, action === 'pause', baseRate);

  isSyncing = true;
  ignoreLocalEventsUntil = Date.now() + 400;

  try {
    if (action === 'play') {
      if (Math.abs(videoEl.currentTime - targetTime) > 0.35) {
        try { videoEl.currentTime = targetTime; } catch {}
      }
      if (videoEl.playbackRate !== baseRate) {
        videoEl.playbackRate = baseRate;
      }
      forcePlayVideo(targetTime);
    } else if (action === 'pause') {
      forcePauseVideo();
      if (Math.abs(videoEl.currentTime - targetTime) > 0.05) {
        try { videoEl.currentTime = targetTime; } catch {}
      }
    } else if (action === 'seek') {
      try { videoEl.currentTime = targetTime; } catch {}
      if (videoEl.playbackRate !== baseRate) {
        videoEl.playbackRate = baseRate;
      }
    } else if (action === 'ratechange') {
      if (videoEl.playbackRate !== baseRate) {
        videoEl.playbackRate = baseRate;
      }
    }
  } finally {
    setTimeout(() => { isSyncing = false; }, 200);
  }
}

// ─── Drift Correction ─────────────────────────────────────────────────────────

function startDriftHeartbeat() {
  if (!isHost) return;
  clearInterval(driftInterval);
  driftInterval = setInterval(() => {
    if (!chrome.runtime?.id) {
      cleanupOrphanedScript();
      return;
    }
    broadcastMovieUrlIfNeeded();
    if (!videoEl) return;
    sendWS({
      type: 'drift-heartbeat',
      currentTime: videoEl.currentTime,
      paused: videoEl.paused,
      rate: videoEl.playbackRate,
      url: window.location.href,
      title: getMovieTitle(),
      sentAt: Date.now(),
    });
  }, DRIFT_HEARTBEAT_INTERVAL_MS);
}

function stopDriftHeartbeat() {
  if (driftInterval) {
    clearInterval(driftInterval);
    driftInterval = null;
  }
}

function applyDriftCorrection(hostTime, sentAt, hostPaused, hostRate) {
  if (isHost || isSyncing || Date.now() < ignoreLocalEventsUntil) return;

  if (!videoEl || !videoEl.isConnected) {
    const v = findMainVideo();
    if (v) {
      videoEl = v;
      attachVideoListeners(v);
    }
  }
  if (!videoEl) return;

  if (typeof hostRate === 'number' && hostRate > 0) {
    hostPlaybackRate = hostRate;
  }
  const baseRate = hostPlaybackRate || 1.0;
  const correctedHostTime = getCorrectedHostTime(hostTime, sentAt, hostPaused, baseRate);

  // If host is paused, ensure guest is paused and aligned
  if (hostPaused) {
    if (!videoEl.paused) {
      forcePauseVideo();
    }
    if (Math.abs(videoEl.currentTime - correctedHostTime) > 0.05) {
      try { videoEl.currentTime = correctedHostTime; } catch {}
    }
    return;
  }

  // If host is playing but guest is paused, let manual play or sync trigger it
  if (videoEl.paused) {
    return;
  }

  const diff = Math.abs(videoEl.currentTime - correctedHostTime);

  // 1. Deadzone (< 100ms): In sync
  if (diff <= 0.10) {
    if (videoEl.playbackRate !== baseRate) {
      videoEl.playbackRate = baseRate;
    }
    return;
  }

  // 2. Large desync (> 1.0s): snap seek
  if (diff > 1.0) {
    const now = Date.now();
    if (now - lastHardSeekTime > HARD_SEEK_COOLDOWN_MS) {
      lastHardSeekTime = now;
      isSyncing = true;
      ignoreLocalEventsUntil = Date.now() + 400;
      videoEl.currentTime = correctedHostTime;
      if (videoEl.playbackRate !== baseRate) videoEl.playbackRate = baseRate;
      setTimeout(() => { isSyncing = false; }, 200);
      log(`Drift snap seek: Δ${diff.toFixed(2)}s -> ${correctedHostTime.toFixed(2)}s`);
    }
    return;
  }

  // 3. Smooth PID Micro-Adjustment (100ms - 1.0s):
  const isLagging = correctedHostTime > videoEl.currentTime;
  const speedDelta = Math.min(diff * 0.04, 0.05);
  const targetRate = isLagging ? (baseRate + speedDelta) : Math.max(baseRate - speedDelta, 0.95);

  videoEl.playbackRate = targetRate;

  clearTimeout(videoEl._togNudgeTimeout);
  videoEl._togNudgeTimeout = setTimeout(() => {
    if (videoEl && !isSyncing) videoEl.playbackRate = baseRate;
  }, 400);
}

// ─── Text chat ────────────────────────────────────────────────────────────────

function sendChatMessage() {
  const input = document.getElementById('tog-chat-input');
  const text  = input.value.trim();
  if (!text) return;

  input.value = '';
  input.style.height = '';

  sendWS({ type: 'chat', text });
  appendChatMessage(text, 'mine');
}

function appendChatMessage(text, who, sender) {
  const container = document.getElementById('tog-chat-messages');
  if (container) {
    const div  = document.createElement('div');
    div.className = `tog-msg ${who}`;

    const meta   = document.createElement('div');
    meta.className = 'tog-msg-meta';
    meta.textContent = who === 'mine' ? 'You' : who === 'system' ? '' : (sender || 'Friend');

    const bubble = document.createElement('div');
    bubble.className = 'tog-msg-bubble';
    bubble.textContent = text;

    if (who !== 'system') div.appendChild(meta);
    div.appendChild(bubble);
    container.appendChild(div);
    container.scrollTop = container.scrollHeight;
  }

  const chatPopover = document.getElementById('tog-chat-popover');
  const isChatOpen = chatPopover && !chatPopover.classList.contains('hidden');

  if (!isChatOpen && who !== 'mine') {
    unreadCount++;
    const badge = document.getElementById('tog-chat-unread-badge');
    const fabBadge = document.getElementById('tog-unread-badge');
    if (badge) {
      badge.textContent = unreadCount > 9 ? '9+' : unreadCount;
      badge.classList.remove('hidden');
    }
    if (fabBadge) {
      fabBadge.textContent = unreadCount > 9 ? '9+' : unreadCount;
      fabBadge.classList.remove('hidden');
    }
    showChatToast(who === 'system' ? text : `${sender || 'Friend'}: ${text}`);
  }
}

// ─── Ad Notification Helpers ──────────────────────────────────────────────────

let myAdInProgress = false;
let adBannerTimeout = null;

function toggleAdNotification() {
  myAdInProgress = !myAdInProgress;
  const btn = document.getElementById('tog-ad-btn');
  if (btn) {
    btn.classList.toggle('active', myAdInProgress);
    btn.setAttribute('title', myAdInProgress ? 'Click when ad ends (notify friend to resume)' : 'Notify friend: I am in an ad break');
  }

  if (myAdInProgress) {
    sendWS({
      type: 'ad-notification',
      status: 'started',
      sentAt: Date.now(),
    });
    appendChatMessage('🍿 You notified friend that you are in an ad break.', 'mine');
    showChatToast('🍿 Sent ad alert to friend');
  } else {
    sendWS({
      type: 'ad-notification',
      status: 'ended',
      sentAt: Date.now(),
    });
    appendChatMessage('🎉 You notified friend that your ad ended.', 'mine');
    showChatToast('🎉 Sent ad done alert to friend');
  }
}

function handleIncomingAdNotification(message) {
  const adBanner = document.getElementById('tog-ad-banner');
  const adText = document.getElementById('tog-ad-banner-text');
  const adActionBtn = document.getElementById('tog-ad-action-btn');

  if (adBannerTimeout) {
    clearTimeout(adBannerTimeout);
    adBannerTimeout = null;
  }

  if (message.status === 'started') {
    appendChatMessage('🍿 Friend is in an ad break. You can pause while waiting!', 'theirs');
    showChatToast('🍿 Friend is in an ad break');
    if (adBanner && adText && adActionBtn) {
      adText.textContent = '🍿 Friend is in an ad break';
      adActionBtn.textContent = '⏸️ Pause';
      adActionBtn.onclick = () => {
        forcePauseVideo();
        onVideoPause();
        adBanner.classList.add('hidden');
        showChatToast('⏸️ Paused for friend');
      };
      adBanner.classList.remove('hidden');
    }
  } else if (message.status === 'ended') {
    appendChatMessage('🎉 Friend\'s ad ended! Ready to play.', 'theirs');
    showChatToast('🎉 Friend\'s ad ended');
    if (adBanner && adText && adActionBtn) {
      adText.textContent = '🎉 Friend\'s ad is done!';
      adActionBtn.textContent = '▶️ Resume';
      adActionBtn.onclick = () => {
        forcePlayVideo();
        onVideoPlay();
        adBanner.classList.add('hidden');
        showChatToast('▶️ Resumed movie');
      };
      adBanner.classList.remove('hidden');
      adBannerTimeout = setTimeout(() => {
        adBanner?.classList.add('hidden');
      }, 8000);
    }
  }
}

// ─── Emoji reactions ──────────────────────────────────────────────────────────

function spawnEmojiFloat(emoji) {
  const el  = document.createElement('div');
  el.className = 'tog-emoji-float';
  el.textContent = emoji;

  // Random horizontal position near the toggle button area
  const x = window.innerWidth - 60 - Math.random() * 80;
  const y = window.innerHeight - 80;
  el.style.left = `${x}px`;
  el.style.top  = `${y}px`;

  document.body.appendChild(el);
  el.addEventListener('animationend', () => el.remove());
}

// ─── WebRTC Bridge Interface ──────────────────────────────────────────────────

function sendToBridge(payload) {
  const frame = document.getElementById('tog-webcam-frame');
  if (frame && frame.contentWindow) {
    try {
      frame.contentWindow.postMessage({ ...payload, source: 'together_content' }, '*');
    } catch (err) {
      log('sendToBridge error:', err);
    }
  }
}

function handleBridgeMessage(data) {
  if (!data || typeof data !== 'object') return;
  const { type } = data;

  switch (type) {
    case 'ws-send':
      if (data.payload) {
        sendWS(data.payload);
      }
      break;

    case 'bridge-ready':
      sendToBridge({ type: 'set-role', isHost });
      if (lastIncomingOffer) {
        sendToBridge(lastIncomingOffer);
      }
      break;

    case 'bridge-status':
      log('Bridge status update:', data.status);
      if (data.status === 'calling') {
        isCallActive = true;
        const callBtn = document.getElementById('tog-call-btn');
        if (callBtn) {
          callBtn.classList.add('active');
          callBtn.classList.remove('tog-btn-ringing');
          callBtn.setAttribute('title', 'End Video Call');
        }
        appendChatMessage('Calling friend...', 'system');
      } else if (data.status === 'connected') {
        isCallActive = true;
        lastIncomingOffer = null;
        const callBtn = document.getElementById('tog-call-btn');
        if (callBtn) {
          callBtn.classList.add('active');
          callBtn.classList.remove('tog-btn-ringing');
          callBtn.setAttribute('title', 'End Video Call');
        }
        document.getElementById('tog-call-banner')?.classList.add('hidden');
        appendChatMessage('Video call connected!', 'system');
      } else if (data.status === 'incoming-offer') {
        document.getElementById('tog-call-banner')?.classList.remove('hidden');
        document.getElementById('tog-call-btn')?.classList.add('tog-btn-ringing');
        appendChatMessage('📞 Friend is calling you... Click "Answer" or the Call button to connect video.', 'system');
      } else if (data.status === 'ended' || data.status === 'disconnected') {
        isCallActive = false;
        lastIncomingOffer = null;
        const callBtn = document.getElementById('tog-call-btn');
        if (callBtn) {
          callBtn.classList.remove('active');
          callBtn.classList.remove('tog-btn-ringing');
          callBtn.setAttribute('title', 'Start Video Call');
        }
        document.getElementById('tog-cam-btn')?.classList.remove('muted');
        document.getElementById('tog-mute-btn')?.classList.remove('muted');
        document.getElementById('tog-call-banner')?.classList.add('hidden');
        if (data.status === 'disconnected') {
          appendChatMessage('Video call disconnected.', 'system');
        }
      }
      break;

    case 'bridge-mute-status':
      document.getElementById('tog-mute-btn')?.classList.toggle('muted', !data.enabled);
      showChatToast(data.enabled ? '🎤 Microphone unmuted' : '🔇 Microphone muted');
      break;

    case 'bridge-cam-status':
      document.getElementById('tog-cam-btn')?.classList.toggle('muted', !data.enabled);
      showChatToast(data.enabled ? '📹 Camera turned on' : '📷 Camera turned off');
      break;

    case 'bridge-toast':
      if (data.message) showChatToast(data.message);
      break;

    case 'bridge-error':
      if (data.message) {
        appendChatMessage(data.message, 'system');
        showChatToast(`⚠️ ${data.message}`);
      }
      break;
  }
}

// Listen to postMessage from the WebRTC bridge iframe
window.addEventListener('message', (event) => {
  if (event.data && event.data.source === 'webrtc_bridge') {
    handleBridgeMessage(event.data);
  }
});

function handleCallToggle() {
  const callBtn = document.getElementById('tog-call-btn');
  if (lastIncomingOffer || (callBtn && callBtn.classList.contains('tog-btn-ringing'))) {
    document.getElementById('tog-call-banner')?.classList.add('hidden');
    callBtn?.classList.remove('tog-btn-ringing');
    sendToBridge({ type: 'answer-call', offer: lastIncomingOffer });
    lastIncomingOffer = null;
    return;
  }

  if (isCallActive) {
    sendToBridge({ type: 'end-call', notify: true });
  } else {
    sendToBridge({ type: 'start-call' });
  }
}

function handleMuteToggle() {
  sendToBridge({ type: 'toggle-mute' });
}

function handleCamToggle() {
  sendToBridge({ type: 'toggle-cam' });
}

// ─── Fullscreen handling ──────────────────────────────────────────────────────

function onFullscreenChange() {
  const fsEl = document.fullscreenElement || document.webkitFullscreenElement;

  if (fsEl) {
    // Entering fullscreen — move overlay inside the fullscreen element
    if (overlayRoot && overlayRoot.parentElement !== fsEl) {
      fsEl.appendChild(overlayRoot);
      log('Overlay reparented into fullscreen element');
    }
  } else {
    // Exiting fullscreen — move back to body
    if (overlayRoot && overlayRoot.parentElement !== document.body) {
      document.body.appendChild(overlayRoot);
      log('Overlay reparented back to body');
    }
  }
}

// ─── Incoming messages from background ───────────────────────────────────────

chrome.runtime.onMessage.addListener((message) => {
  if (message.source !== 'background') return;

  switch (message.type) {
    // ── Room state ─────────────────────────────────────────────────────────
    case 'room-state':
    case 'room-created':
    case 'joined':
    case 'reconnected':
      roomCode      = message.roomCode;
      participantId = message.participantId;
      isHost        = message.isHost;
      isInRoom      = true;

      injectOverlay();
      const drawerRoomEl = document.getElementById('tog-drawer-room-code');
      if (drawerRoomEl) drawerRoomEl.textContent = roomCode || '———';

      startVideoObserver();
      startMovieSyncMonitor();

      sendToBridge({ type: 'set-role', isHost });

      if (isHost) {
        startDriftHeartbeat();
        broadcastMovieUrlIfNeeded(true);
        appendChatMessage('Room created. Share the code!', 'system');
      } else {
        startClockSync();
        if (message.movieUrl) {
          handleIncomingMovieUrl(message.movieUrl, message.movieTitle);
        }
        sendWS({ type: 'state-request' });
        appendChatMessage('Joined room! Ready to watch together.', 'system');
      }

      if (message.type === 'reconnected') {
        appendChatMessage('Reconnected to room.', 'system');
      }
      break;

    case 'you-are-host':
      isHost = true;
      sendToBridge({ type: 'set-role', isHost: true });
      if (clockSyncInterval) {
        clearInterval(clockSyncInterval);
        clockSyncInterval = null;
      }
      startDriftHeartbeat();
      broadcastMovieUrlIfNeeded(true);
      appendChatMessage('You are now the host.', 'system');
      break;

    case 'peer-joined':
      appendChatMessage('Friend joined the room!', 'system');
      if (isHost) {
        broadcastMovieUrlIfNeeded(true);
      }
      break;

    case 'peer-reconnected':
      appendChatMessage('Friend reconnected.', 'system');
      if (isHost) {
        broadcastMovieUrlIfNeeded(true);
      }
      break;

    case 'peer-disconnected':
      appendChatMessage('Friend disconnected.', 'system');
      break;

    case 'left-room':
      isInRoom = false;
      roomCode = null;
      participantId = null;
      isHost = false;
      stopDriftHeartbeat();
      if (movieSyncInterval) {
        clearInterval(movieSyncInterval);
        movieSyncInterval = null;
      }
      if (clockSyncInterval) {
        clearInterval(clockSyncInterval);
        clockSyncInterval = null;
      }
      if (overlayRoot) {
        overlayRoot.remove();
        overlayRoot = null;
      }
      const syncBanner = document.getElementById('tog-sync-banner');
      if (syncBanner) syncBanner.remove();
      const movieBanner = document.getElementById('tog-movie-banner');
      if (movieBanner) movieBanner.remove();
      sendToBridge({ type: 'end-call', notify: false });
      log('Left room');
      break;

    // ── Server asks us to send state snapshot (for reconnected guest) ──────
    case 'send-state-snapshot':
      if (isHost) {
        sendWS({
          type: 'state-snapshot',
          currentTime: videoEl ? videoEl.currentTime : 0,
          paused: videoEl ? videoEl.paused : true,
          rate: videoEl ? videoEl.playbackRate : 1.0,
          url: window.location.href,
          title: getMovieTitle(),
          sentAt: Date.now(),
        });
        log('Host dispatched state snapshot to guest:', window.location.href);
      }
      break;

    // ── Server asks guest to request state ─────────────────────────────────
    case 'request-state':
      sendWS({ type: 'state-request' });
      break;

    // ── Movie change broadcast from host ──────────────────────────────────
    case 'movie-change':
      if (!isHost && message.url) {
        handleIncomingMovieUrl(message.url, message.title);
      }
      break;

    // ── Incoming state snapshot (for guest on join/reconnect) ──────────────
    case 'state-snapshot':
      if (!isHost) {
        if (message.url) {
          handleIncomingMovieUrl(message.url, message.title);
        }
        applySync(message.paused ? 'pause' : 'play', message.currentTime, message.sentAt, message.rate);
      }
      break;

    // ── Playback sync ───────────────────────────────────────────────────────
    case 'sync':
      if (!videoEl || !videoEl.isConnected) {
        const vSync = findMainVideo();
        if (vSync) {
          videoEl = vSync;
          attachVideoListeners(vSync);
        }
      }
      if (!isHost && message.url) {
        handleIncomingMovieUrl(message.url, message.title);
      }
      if (!syncEnabled) break;
      applySync(message.action, message.currentTime, message.sentAt, message.rate);
      break;

    // ── Drift heartbeat ─────────────────────────────────────────────────────
    case 'drift-heartbeat':
      if (!isHost) {
        if (message.url) {
          handleIncomingMovieUrl(message.url, message.title);
        }
        if (syncEnabled) {
          applyDriftCorrection(message.currentTime, message.sentAt, message.paused, message.rate);
        }
      }
      break;

    // ── Chat ────────────────────────────────────────────────────────────────
    case 'chat':
      appendChatMessage(message.text, 'theirs');
      break;

    // ── Emoji ───────────────────────────────────────────────────────────────
    case 'emoji':
      spawnEmojiFloat(message.emoji);
      break;

    // ── WebRTC signaling (forward to bridge) ────────────────────────────────
    case 'offer':
      lastIncomingOffer = message;
      document.getElementById('tog-call-banner')?.classList.remove('hidden');
      document.getElementById('tog-call-btn')?.classList.add('tog-btn-ringing');
      appendChatMessage('📞 Friend is calling you... Click "Answer" or the Call button to connect video.', 'system');
      sendToBridge(message);
      break;

    case 'answer':
      lastIncomingOffer = null;
      document.getElementById('tog-call-banner')?.classList.add('hidden');
      sendToBridge(message);
      break;

    case 'ice-candidate':
      sendToBridge(message);
      break;

    case 'call-ended':
      lastIncomingOffer = null;
      isCallActive = false;
      document.getElementById('tog-call-banner')?.classList.add('hidden');
      const callEndedBtn = document.getElementById('tog-call-btn');
      if (callEndedBtn) {
        callEndedBtn.classList.remove('active');
        callEndedBtn.classList.remove('tog-btn-ringing');
        callEndedBtn.setAttribute('title', 'Start Video Call');
      }
      sendToBridge({ type: 'call-ended' });
      appendChatMessage('Video call ended by friend.', 'system');
      break;

    // ── Ad Notification ──────────────────────────────────────────────────────
    case 'ad-notification':
      handleIncomingAdNotification(message);
      break;

    // ── Clock Synchronization ────────────────────────────────────────────────
    case 'clock-ping':
      handleClockPing(message);
      break;

    case 'clock-pong':
      handleClockPong(message);
      break;
  }
});

// ─── Bootstrap ───────────────────────────────────────────────────────────────

function initRoom(data) {
  if (!data || !data.roomCode || isInRoom) return;
  roomCode      = data.roomCode;
  participantId = data.participantId;
  isHost        = data.isHost ?? false;
  isInRoom      = true;

  injectOverlay();
  const pipRoomEl = document.getElementById('tog-pip-room-code') || document.getElementById('tog-drawer-room-code');
  if (pipRoomEl) pipRoomEl.textContent = roomCode || '———';

  startVideoObserver();
  startMovieSyncMonitor();

  if (isHost) {
    startDriftHeartbeat();
    broadcastMovieUrlIfNeeded(true);
  } else {
    startClockSync();
    if (data.movieUrl) {
      handleIncomingMovieUrl(data.movieUrl, data.movieTitle);
    }
  }

  // Ask for fresh state from host
  sendWS({ type: 'state-request' });
  log('Restored room session:', roomCode, 'isHost:', isHost);
}

// Start watching for video elements immediately on page load
startVideoObserver();

// Restore state if already in a room (e.g. page reload or navigation within active session)
try {
  if (chrome.runtime?.id && chrome.storage?.session) {
    chrome.storage.session.get(['roomCode', 'participantId', 'isHost', 'movieUrl', 'movieTitle'], (data) => {
      if (chrome.runtime?.id && data && data.roomCode) {
        initRoom(data);
      } else if (chrome.runtime?.id) {
        sendToBackground({ type: 'get-room-state' });
      }
    });
  } else if (chrome.runtime?.id) {
    sendToBackground({ type: 'get-room-state' });
  }
} catch {}
